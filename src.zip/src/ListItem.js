import React, { Component } from 'react';

class ListItem extends Component {
    constructor(props) {
      super(props);
      };
      
      onDeleteClick (e) {
        console.log(e);
            }
            onChangeClick(e) {
                console.log(e);
            }

    render() {
        const editable = !this.props.children.action ? (
            <div>
        <input type="text" value = {this.props.children.code} className="listCode"/>
        <input type="text" value = {this.props.children.produt} className="listCode"/>
        <input type="text" value = {this.props.children.stock} className="listCode"/>
        <input type="text" value = {this.props.children.expiry_date} className="listCode"/>
        <input type="text" type="submit" value = "Change" onClick={e => this.handleChangeClick(child,e)} onClick = {this.onChangeClick} className="listCode"/>
        <input type="text" type="submit" value = "Delete" onClick = {this.onDeleteClick} className="listCode"/></div>) : (<div className="Form" >
        <input type="text" defaultValue = {this.props.children.code} className="listCode"/>
        <input type="text" defaultValue = {this.props.children.produt} className="listCode"/>
        <input type="text" defaultValue = {this.props.children.stock} className="listCode"/>
        <input type="text" defaultValue = {this.props.children.expiry_date} className="listCode"/>
        <input type="text" type="submit" value = "save" onClick = {this.onSaveClick} className="listCode"/>
        <input type="text" type="submit" value = "Delete" onClick = {this.onDeleteClick} className="listCode"/>   
        </div>
        
        )
      return (
        <div className="inventory">
       {editable}
        
        </div>
      );
    }
  }
  export default ListItem;