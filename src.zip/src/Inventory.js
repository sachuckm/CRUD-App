import React, { Component } from 'react';
import './Login.css';
import ListItem from './ListItem.js'
import NewProduct from './NewProduct';


class Inventory extends Component {
    constructor(props) {
      super(props);
      this.state = {addProduct:false,
          products:[{
                id:0,
                code:1,
                produt:'Really awesome apples',
                stock:35,
                expiry_date:'3rd march',
                action:''
          },
          {
            id:1,
            code:1,
            produt:'Really awesome apples',
            stock:35,
            expiry_date:'3rd march',
            action:''
      },
      {
        id:2,
        code:1,
        produt:'Really awesome apples',
        stock:35,
        expiry_date:'3rd march',
        action:''
  },{
    id:3,
    code:1,
    produt:'Really awesome apples',
    stock:35,
    expiry_date:'3rd march',
    action:''
},{
    id:4,
    code:1,
    produt:'Really awesome apples',
    stock:35,
    expiry_date:'3rd march',
    action:''
},{
    id:5,
    code:1,
    produt:'Really awesome apples',
    stock:35,
    expiry_date:'3rd march',
    action:''
},{
    id:6,
    code:1,
    produt:'Really awesome apples',
    stock:35,
    expiry_date:'3rd march',
    action:''
},{
    id:7,
    code:1,
    produt:'Really awesome apples',
    stock:35,
    expiry_date:'3rd march',
    action:''
},{
    id:8,
    code:1,
    produt:'Really awesome apples',
    stock:35,
    expiry_date:'3rd march',
    action:''
}]
      };
    }
    onDeleteClick (e) {
console.log(e);
    }
    onChangeClick(e) {
        console.log(e);

    }
    onproduct () {
        this.setState({addProduct: true});
    }
    render() {
        const listItems =  this.state.products.map((produt) =>
    <ListItem onClick={this.onChangeClick} key={produt.id}>
      {produt}
    </ListItem>
  
)
  
      return (
        <div className="inventory">
         {listItems}
        </div>
      );
    }
  }
  export default Inventory;