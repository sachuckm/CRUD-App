import React, { Component } from 'react';
import './NewProduct.css';
import logo from '../src/images/logo.png';

class NewProduct extends Component {
    constructor(props) {
      super(props);
      this.state = {
          
      };
    }
    render() {
        const image = (<img src={logo}></img>);
        const product = (
        <div className="productBox"> 
         <form className="productForm" onSubmit={this.handleSubmit}>
        
        <label className="basic">Basic</label>
        <label className="productName">Product name</label>
           <input className="productNameInput" type="text" />
           <input className="productcode" placeholder="Product Code" type="text" /> 
            
           <label label className="Inventory">Inventory</label>
           <input className="ProductQty" placeholder="Quantity(Number)" type="text" /> 
           <input className="ProductExpiry" placeholder="Expiry Date" type="text" /> 
            <input className="productSubmit" type="Submit" value="Add Product" />
            <input className="cancelSubmit" type="button" value="Cancel" />
            
           
           </form>
       </div>);
      return (
        <div className="NewProduct">
        <div className = "headerproduct">
        {image}
        </div>
        {product}
        </div>
      );
    }
  }
  export default NewProduct;