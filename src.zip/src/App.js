import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
//import Login from './Login';

class App extends Component {
  render() {
    return (
     // <Login></Login> 
    );
  }
}

export default App;
